
<!-- HERO
================================================== -->
<section id="hero" data-type="background" data-speed="5">
	<article>
		<div class="container clearfix">
			<div class="row">
				
				<div class="col-sm-5">
					<img src="<?php bloginfo('stylesheet_directory'); ?>/assets/img/logo-badge.png" alt="Bootstrap to WordPress" class="logo">
				</div><!-- col -->
				
				<div class="col-sm-7 hero-text">
					<h1><?php bloginfo('name'); ?></h1>
					<p class="lead"><?php bloginfo('description'); ?></p>				
										
				</div><!-- col -->
				
			</div><!-- row -->
		</div><!-- container -->
	</article>
</section><!-- hero -->